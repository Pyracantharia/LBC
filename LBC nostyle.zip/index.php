<?php
header("location:View/index.php");

?>